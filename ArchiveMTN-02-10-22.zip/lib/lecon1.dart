import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:projets/menu.dart';
import 'package:projets/infosymbol.dart';
import 'package:projets/menulecon.dart';

extension ColorExtension on String {
  toColor6() {
    var hexString = this;
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}


void main() {
  runApp(const MyLecon1());
}

class MyLecon1 extends StatelessWidget {
  const MyLecon1({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    // Set landscape orientation
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      routes: {
        '/menu': (context) => MyMenu(),
      },

      theme: ThemeData(

        //primarySwatch: '#fcca0c'.toColor2(),
      ),
      home: const MyHomePage(title: ''),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int state = 1;
  String theaudio = '';
  final player = AudioPlayer();
  static Color thebackcolor0 =  Colors.white;
  static Color thebackcolor1 =  Colors.white;
  static Color thebackcolor2 =  Colors.white;
  static Color thebackcolor3 =  Colors.white;
  static Color thebackcolor4 =  Colors.white;
  static Color thebackcolor5 =  Colors.white;
  static Color thebackcolor6 =  Colors.white;
  static Color thebackcolor7 =  Colors.white;
  static Color thebackcolor8 =  Colors.white;
  static Color thebackcolor9 =  Colors.white;
  static Color thebackcolor10 =  Colors.white;
  static Color thebackcolor11 =  Colors.white;
  static Color thebackcolor12 =  Colors.white;
  static Color thebackcolor13 =  Colors.white;
  static Color thebackcolor14 =  Colors.white;
  static Color thebackcolor15 =  Colors.white;
  static Color thebackcolor16 =  Colors.white;
  static Color thebackcolor17 =  Colors.white;
  static Color thebackcolor18 =  Colors.white;
  static Color thebackcolor19 =  Colors.white;
  static Color thebackcolor20 =  Colors.white;
  static Color thebackcolor21 =  Colors.white;
  static Color thebackcolor22 =  Colors.white;

  var colorArray = new List<Color>.filled(23,Colors.white, growable:true);
  //static List<Color>colorArray.filled(0,0, growable:true);

  void SetColorArray(){
    colorArray = [
      thebackcolor1, thebackcolor2, thebackcolor3,
      thebackcolor4, thebackcolor5, thebackcolor6,
      thebackcolor7, thebackcolor8, thebackcolor9,
      thebackcolor10, thebackcolor11, thebackcolor12,
      thebackcolor13, thebackcolor14, thebackcolor15,
      thebackcolor16, thebackcolor17, thebackcolor18,
      thebackcolor18, thebackcolor19, thebackcolor20,
      thebackcolor21, thebackcolor22
    ];
  }

  String audio0 = 'audio/lecon1/malenephrase.mp3';
  String audio1 = 'audio/lecon1/malene.mp3';
  String audio2 = 'audio/lecon1/ecrit.mp3';
  String audio3 = 'audio/lecon1/messages.mp3';
  String audio4 = 'audio/lecon1/boni.mp3';
  String audio5= 'audio/lecon1/ma.mp3';
  String audio6 = 'audio/lecon1/ri.mp3';
  String audio7 = 'audio/lecon1/sa.mp3';
  String audio8 = 'audio/lecon1/ni.mp3';
  String audio10 = 'audio/lecon1/a.mp3';
  String audio11 = 'audio/lecon1/i.mp3';


  @override
  void dispose() {
    player.dispose();
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    //SetColorArray();
    state = 0;
    //changeHilght();
   // player = AudioPlayer();
  }

  void playSound(String thesound) {
    player.play(AssetSource('audio/lecon1/$thesound.mp3'));
  }

  void RepeatVoice(){
    player.play(AssetSource(theaudio));
  }

  void changeHilght() async{
    setState(() {
      if(state==0){
        theaudio = audio0;
      }else if(state==1){
        theaudio = audio1;
      }else if(state==2){
        theaudio = audio2;
      }else if(state==3){
        theaudio = audio3;
      }else if(state==4){
        theaudio = audio4;
      }else if(state==5){
        theaudio = audio5;
      }else if(state==6){
        theaudio = audio6;
      }else if(state==7){
        theaudio = audio7;
      }else if(state==8){
        theaudio = audio8;
      }else if(state==9 || state == 11){
        theaudio = audio10;
      }else{
        theaudio = audio11;
      }
      //player.setAsset(theaudio);
      player.play(AssetSource(theaudio));
      try{
        if(state > 12){
          state = 0;
        }
        for(int i = 0; i<22; i++ ){
          if(state ==  i){
            colorArray[i] = Colors.yellowAccent;
            //    'thebackcolor$state' =  Colors.white;
          }else{
            colorArray[i] =   Colors.white;
          }
        }
        //SetColorArray();
        state = state+1;
        print(state);
      }on Exception catch (_){
        print('error');
      }
      //theaudio = 'audio$state';
    });
    print(theaudio);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //backgroundColor: '#fcca0c'.toColor2(),
      appBar: AppBar(
        centerTitle: true,
        toolbarHeight: 30,
        backgroundColor: '#fcca0c'.toColor6(),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title + 'Leçon 1',style: TextStyle(color: Color(0xff000000),fontStyle: FontStyle.italic),),
      ),
      body: SingleChildScrollView(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize : MainAxisSize.min,
          children: <Widget> [
            Padding(
              padding: EdgeInsets.all(10), //apply padding to all four sides
              child: Text('Les sons a et i',style: TextStyle(fontSize: 25,fontFamily: 'Poppins',),),
            ),
      SizedBox( //  Image illustration
        width: 200,
        height: 30,
      ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Expanded(
                SizedBox( //  Image illustration
                  width: 200,
                  height: 300,
                  child:Column(
                    children: <Widget>[
                      Row( //Menu buttons---------
                        children: <Widget>[
                          SizedBox(
                            width: 100,
                            height: 50,
                            child:Card(
                              child: new InkWell(
                                onTap: () {
                                  Navigator.pushNamed(context, '/menu');
                                },
                                child: const Icon(Icons.arrow_back_ios),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 50,
                            height: 50,
                            child:Card(
                              child: new InkWell(
                                onTap: () {
                                  //print("tapped");
                                  RepeatVoice();
                                },
                                child: const Icon(Icons.repeat),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 50,
                            height: 50,
                            child:Card(
                              child: new InkWell(
                                onTap: () {

                                  changeHilght();
                                },
                                child: const Icon(Icons.speaker_notes),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: <Widget>[
                          SizedBox(
                            width: 200,
                            height: 200,
                            child: Image(
                              image:AssetImage('assets/lecon/l1.png'),
                            ),
                          ),
                        ],
                      ),
                      //--- Menu -----------------------
                    ],
                  ),
                ),
                // ),
                // Expanded(
                SizedBox( // les phrases
                  width: 370,
                  height: 300,
                  child: Column(
                    children: <Widget>[
                      // Ligne 1----------------------------------------///
                      Row(// Ligne 1
                        children: <Widget>[
                          SizedBox( // phrase part 1 malène écrit des messages à boni.
                            width: 20,
                            height: 50,
                            child:Text('m',
                              style: TextStyle( fontWeight: FontWeight.w600,fontSize: 20,fontFamily: 'Poppins',
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = thebackcolor0
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 13,
                            height: 50,
                            child:Text('a',
                              style: TextStyle( color: Colors.red,fontWeight: FontWeight.w600,fontSize: 20,fontFamily: 'Poppins',
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = thebackcolor0
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 45,
                            height: 50,
                            child:Text('lène',
                              style: TextStyle(fontWeight: FontWeight.w600,fontSize: 20,fontFamily: 'Poppins',
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = thebackcolor0
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 5,
                            height: 50,
                            child:Text('  ',
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 35,
                            height: 50,
                            child:Text('écr',
                              style: TextStyle(fontWeight: FontWeight.w600,fontSize: 20,fontFamily: 'Poppins',
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = thebackcolor0
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 7,
                            height: 50,
                            child:Text('i',
                              style: TextStyle( color: Colors.red,fontWeight: FontWeight.w600,fontSize: 20,fontFamily: 'Poppins',
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = thebackcolor0
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 5,
                            height: 50,
                            child:Text('t',
                              style: TextStyle(fontWeight: FontWeight.w600,fontSize: 20,fontFamily: 'Poppins',
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = thebackcolor0
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // space.
                            width: 5,
                            height: 50,
                            child:Text('  ',),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 104,
                            height: 50,
                            child:Text(' des mess',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = thebackcolor0
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 13,
                            height: 50,
                            child:Text('a',
                              style: TextStyle( color: Colors.red,fontFamily: 'Poppins',fontWeight: FontWeight.w600,fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = thebackcolor0
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 100,
                            height: 50,
                            child:Text('ges à bon',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = thebackcolor0
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 3,
                            height: 50,
                            child:Text('i',
                              style: TextStyle( color: Colors.red,fontFamily: 'Poppins',fontWeight: FontWeight.w600,fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = thebackcolor0
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                        ],
                        //Text('malène écrit des messages à boni.'),
                      ),
                      // Ligne 2----------------------------------------///
                      Row(// Ligne 2
                        children: <Widget>[
                          SizedBox( // phrase part 1 malène écrit des messages à boni.
                            width: 23,
                            height: 50,
                            child:Text('m',
                              style: TextStyle( fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[1]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 15,
                            height: 50,
                            child:Text('a',
                              style: TextStyle( color: Colors.red,fontFamily: 'Poppins',fontWeight: FontWeight.w600,fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[1]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 45,
                            height: 50,
                            child:Text('lène',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[1]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 5,
                            height: 50,
                            child:Text('  ',
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 35,
                            height: 50,
                            child:Text('écr',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[2]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 7,
                            height: 50,
                            child:Text('i',
                              style: TextStyle( color: Colors.red,fontFamily: 'Poppins',fontWeight: FontWeight.w600,fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[2]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 20,
                            height: 50,
                            child:Text('t',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[2]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // space.
                            width: 5,
                            height: 80,
                            child:Text(' ',),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 55,
                            height: 50,
                            child:Text('mess',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[3]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 15,
                            height: 50,
                            child:Text('a',
                              style: TextStyle( color: Colors.red,fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[3]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 60,
                            height: 50,
                            child:Text('ges',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[3]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 40,
                            height: 50,
                            child:Text('bon',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[4]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),

                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 2,
                            height: 50,
                            child:Text('i',
                              style: TextStyle( color: Colors.red,fontFamily: 'Poppins',fontWeight: FontWeight.w600,fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[4]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                        ],
                        //Text('malène écrit des messages à boni.'),
                      ),
                      // Ligne 3----------------------------------------///
                      Row(// Ligne 3
                        children: <Widget>[
                          SizedBox( // phrase part 1 malène écrit des messages à boni.
                            width: 20,
                            height: 50,
                            child:Text('m',
                              style: TextStyle( fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[5]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 10,
                            height: 50,
                            child:Text('a',
                              style: TextStyle( color: Colors.red,fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[5]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),

                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 30,
                            height: 50,
                            child:Text('        ',
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 8,
                            height: 50,
                            child:Text('r',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[6]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 5,
                            height: 50,
                            child:Text('i',
                              style: TextStyle( color: Colors.red,fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[6]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),

                          SizedBox( // space.
                            width: 30,
                            height: 70,
                            child:Text('            ',),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 11,
                            height: 50,
                            child:Text('s',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[7]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 10,
                            height: 50,
                            child:Text('a',
                              style: TextStyle( color: Colors.red,fontFamily: 'Poppins',fontWeight: FontWeight.w600,fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[7]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // space.
                            width: 30,
                            height: 80,
                            child:Text('            ',),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 15,
                            height: 50,
                            child:Text('n',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[8]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 2,
                            height: 50,
                            child:Text('i',
                              style: TextStyle( color: Colors.red,fontWeight: FontWeight.w600,fontFamily: 'Poppins',fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[8]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                        ],
                        //Text('malène écrit des messages à boni.'),
                      ),
// Ligne 4----------------------------------------///
                      Row(// Ligne 4
                        children: <Widget>[

                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 10,
                            height: 50,
                            child:Text('a',
                              style: TextStyle( color: Colors.red,fontFamily: 'Poppins',fontWeight: FontWeight.w600,fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[9]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),

                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 30,
                            height: 50,
                            child:Text('        ',
                            ),
                          ),

                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 5,
                            height: 50,
                            child:Text('i',
                              style: TextStyle( color: Colors.red,fontFamily: 'Poppins',fontWeight: FontWeight.w600,fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[10]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),

                          SizedBox( // space.
                            width: 30,
                            height: 50,
                            child:Text('            ',),
                          ),

                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 10,
                            height: 50,
                            child:Text('a',
                              style: TextStyle( color: Colors.red,fontFamily: 'Poppins',fontWeight: FontWeight.w600,fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[11]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                          SizedBox( // space.
                            width: 30,
                            height: 50,
                            child:Text('            ',),
                          ),

                          SizedBox( // phrase part 2 malène écrit des messages à boni.
                            width: 2,
                            height: 50,
                            child:Text('i',
                              style: TextStyle( color: Colors.red,fontFamily: 'Poppins',fontWeight: FontWeight.w600,fontSize: 20,
                                  background: Paint()
                                    ..strokeWidth = 3.0
                                    ..color = colorArray[12]
                                    ..style = PaintingStyle.stroke
                                    ..strokeJoin = StrokeJoin.round),
                            ),
                          ),
                        ],
                        //Text('malène écrit des messages à boni.'),
                      ),
                    ],
                  ),
                ),
                // ),

              ],
            ),
            Padding(
              padding: EdgeInsets.all(10), //apply padding to all four sides
              child: Text('Les syllabes avec a et i',style: TextStyle(fontSize: 30,fontFamily: 'Poppins',),),
            ),

            Row( //---------------- Les  sons ------------
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                Column(
                  children:<Widget> [
                    // Les sons ----------------------
                    Row( // ------Ligne 1 sons --------
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('ra');
                              },
                              child: Center(child: Text('ra',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('ba');
                              },
                              child: Center(child: Text('ba',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('ca');
                              },
                              child: Center(child: Text('ca',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('da');
                              },
                              child: Center(child: Text('da',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('na');
                              },
                              child: Center(child: Text('na',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),

                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('fa');
                              },
                              child: Center(child: Text('fa',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),

                      ],
                    ),
                    Row( // ------Ligne 2 sons --------
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('ma');
                              },
                              child: Center(child: Text('ma',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('ta');
                              },
                              child: Center(child: Text('ta',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('pa');
                              },
                              child: Center(child: Text('pa',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('la');
                              },
                              child: Center(child: Text('la',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('sa');
                              },
                              child: Center(child: Text('sa',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('va');
                              },
                              child: Center(child: Text('va',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                      ],
                    ),
                    Row( // ------Ligne 3 sons --------
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('mi');
                              },
                              child: Center(child: Text('mi',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('ti');
                              },
                              child: Center(child: Text('ti',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('pi');
                              },
                              child: Center(child: Text('pi',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('li');
                              },
                              child: Center(child: Text('li',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('si');
                              },
                              child: Center(child: Text('si',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),

                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('fi');
                              },
                              child: Center(child: Text('fi',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),

                          ),
                        ),
                      ],
                    ),
                    Row( // ------Ligne 4 sons --------
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('bi');
                              },
                              child: Center(child: Text('bi',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('di');
                              },
                              child: Center(child: Text('di',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('gi');
                              },
                              child: Center(child: Text('gi',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('vi');
                              },
                              child: Center(child: Text('vi',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('ki');
                              },
                              child: Center(child: Text('ki',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 100,
                          height: 80,
                          child:Card(
                            child: new InkWell(
                              onTap: () {
                                playSound('si');
                              },
                              child: Center(child: Text('si',style: TextStyle(fontSize: 35,fontFamily: 'Poppins',),)),
                            ),
                          ),
                        ),
                      ],
                    ),


                  ],


                ),
              ],
            ),
            //---------------- Les phrases de fin ------------
      Row( //---------------- Les  sons ------------
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: <Widget>[
      Column(
      children:<Widget> [
        SizedBox(
          width: 300,
          height: 20,
        ),
        SizedBox(
          width: 550,
          height: 300,
          child: Text('Marlene parle par SMS a boni, il ya des pagnes kitas sur la natte.',
            style: TextStyle(color: Colors.black,fontSize:30,fontFamily: 'Poppins',
                background: Paint()
                  ..strokeWidth = 25.0
                  ..color = Colors.white
                  ..style = PaintingStyle.fill
                  ..strokeJoin = StrokeJoin.round),
          ),

        ),

      ],
      ),
          ],
      ),

          ],
        ),
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}