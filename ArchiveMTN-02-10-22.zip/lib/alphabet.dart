import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:projets/menu.dart';


extension ColorExtension on String {
  toColor7() {
    var hexString = this;
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}


void main() {
  runApp(const MyAlphabet());
}

class MyAlphabet extends StatelessWidget {
  const MyAlphabet({Key? key}) : super(key: key);

  // This widget is the root of your application.



  @override
  Widget build(BuildContext context) {

    // Set landscape orientation
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      routes: {
        '/menu': (context) => MyMenu(),

      },
      theme: ThemeData(

        //primarySwatch: '#fcca0c'.toColor2(),
      ),
      home: const MyHomePage(title: ''),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  final player = AudioPlayer();
  void playSound(String thesound) {
    player.play(AssetSource('audio/lecon1/$thesound.mp3'));
  }


  @override
  Widget build(BuildContext context) {
    onWillPop: () async {
      // show the snackbar with some text
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('The System Back Button is Deactivated')));
      return false;
    };
    return Scaffold(
      //backgroundColor: '#fcca0c'.toColor2(),
      appBar: AppBar(
        centerTitle: true,
        toolbarHeight: 50,
        backgroundColor: '#fcca0c'.toColor7(),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title + 'Les lettres de l\'alphabets',style: TextStyle(color: Color(0xff000000),fontStyle: FontStyle.italic),),
      ),
      body: SingleChildScrollView(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.


        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize : MainAxisSize.min,

          children: <Widget> [

            Padding(
              padding: EdgeInsets.all(10), //apply padding to all four sides
              child: Text('Alphabets',style: TextStyle(fontSize: 25),),
            ),
// --- Ligne  1 -------------
            Row( // Ligne 1
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 75,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('a');
                      },
                      child: Column(
                          children: <Widget>[
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        SizedBox(
                        width: 30,
                        height: 50,
                          child:Text('a',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                        ),
                        SizedBox(
                          width: 30,
                          height: 50,
                          child:Text('A',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                        ),
                      ],
                            ),
                          ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('b');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('b',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('B',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('c');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('c',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('C',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('d');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('d',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('D',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                // ),
                // Expanded(

              ],
            ),
            // --- Ligne  2 -------------
            Row( // Ligne 2
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 75,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('e');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('e',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('E',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('f');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('f',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('F',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('g');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('g',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('G',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('h');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('h',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('H',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                // ),
                // Expanded(

              ],
            ),
            Row( // Ligne 3
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 75,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('i');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('i',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('I',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('j');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('j',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('J',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('k');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('k',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('K',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('l');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('l',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('L',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                // ),
                // Expanded(

              ],
            ),
            Row( // Ligne 5
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 75,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('m');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 40,
                                height: 50,
                                child:Text('m',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 35,
                                height: 50,
                                child:Text('M',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('n');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('n',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('N',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('o');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('o',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('O',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('p');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('p',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('P',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                // ),
                // Expanded(

              ],
            ),
            Row( // Ligne 5
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 75,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('q');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('q',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('Q',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('r');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('r',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('R',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('s');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('s',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('S',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('t');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('t',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('T',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                // ),
                // Expanded(

              ],
            ),
            Row( // Ligne 7
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 75,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('u');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('U',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('U',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('v');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('v',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('V',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('w');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 40,
                                height: 50,
                                child:Text('w',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 40,
                                height: 50,
                                child:Text('W',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('x');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('x',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('X',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Row( // Ligne 8
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 75,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('y');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('y',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('Y',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 75,

                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        playSound('z');
                      },
                      child: Column(
                        children: <Widget>[
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: <Widget>[
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('z',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),
                              SizedBox(
                                width: 30,
                                height: 50,
                                child:Text('Z',style: TextStyle(fontSize: 40,fontFamily: 'Poppins')),
                              ),

                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 70,

                  child:Card(
                    color: Colors.amberAccent,
                    child: new InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, '/menu');
                      },
                      child: const Icon(Icons.arrow_back_ios),
                    ),
                  ),
                ),
                // ),
                // Expanded(
              ],
            ),
          ],
        ),
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
