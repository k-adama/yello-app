import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:projets/menu.dart';
import 'package:projets/adminlogin.dart';


extension ColorExtension on String {
  toColor() {
    var hexString = this;
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    // Set landscape orientation
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      routes: {
        '/menu': (context) => MyMenu(),
        '/adminlogin': (context) => MyLogin(),


      },
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.amber,
      ),
      home: const MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);
  final String title;
  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  //Color Newcolor = const Color('0xFFffce00');
  int CountIndex = 0;
  String TheLogo = 'assets/mtn/mtn0.png';

  StarCount(){
    Future.delayed(Duration(seconds: 10), (){
      Navigator.pushReplacementNamed(context, '/menu');

    });
  }


  void initState()
  {
    //super.initState();
    //GetLogoPart();//call it over here
    setState(() {});
    StarCount();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: '#fcca0c'.toColor(),
      body: Center(
        child: Image(
          image:AssetImage('assets/mtn/mtnlogo.gif'),
        ),
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Add your onPressed code here!

          Navigator.pushReplacementNamed(context, '/adminlogin');
        },
        backgroundColor: Colors.limeAccent,
        child: const Icon(Icons.settings),
      ),
    );
  }
}
