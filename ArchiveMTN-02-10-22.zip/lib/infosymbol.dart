import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:projets/evaluationSymbol.dart';
import 'package:flutter/services.dart';
import 'package:projets/menu.dart';

extension ColorExtension on String {
  toColor2() {
    var hexString = this;
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}


void main() {
  runApp(const MySymbolInfo());
}

class MySymbolInfo extends StatelessWidget {
  const MySymbolInfo({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    // Set landscape orientation
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    return MaterialApp(
      routes: {
        '/menu': (context) => MyMenu(),
        '/evaluationSymbol': (context) => MySymbolE(),
      },
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',

      theme: ThemeData(

        //primarySwatch: '#fcca0c'.toColor2(),
      ),
      home: const MyHomePage(title: ''),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);


  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;
  String Phrase = '';
  String theAudioPath = '';
  String imgSymbolPath = '';
  String ImgIllustrationPath = '';

  var SymbolName = new List<String>.filled(23,'', growable:true);
  var AudioName = new List<String>.filled(23,'', growable:true);
  var ImagesSymbole = new List<String>.filled(23,'', growable:true);
  var Imagesillustration = new List<String>.filled(23,'', growable:true);

  void Navigate(int index){
    _counter = _counter + index;
    setState(() {
      Phrase = SymbolName[_counter];
      theAudioPath = AudioName[_counter];
    });
  }

  void SetSymboleImg(){
    ImagesSymbole = [
      '', '', '',
      '', '', '',
      '', '', '',
      ''
    ];
  }

  void SetIllustrationImg(){
    Imagesillustration = [
      '', '', '',
      '', '', '',
      '', '', '',
      ''
    ];
  }

  void SetSymboleName(){
    SymbolName = [
      '', '', '',
      '', '', '',
      '', '', '',
      ''
    ];
  }

  void SetAudioPath(){
    AudioName = [
      '', '', '',
      '', '', '',
      '', '', '',
      ''
    ];
  }

  @override
  void initState() {
    super.initState();
    SetSymboleImg();
    SetAudioPath();
    SetSymboleName();
    SetIllustrationImg();
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      //backgroundColor: '#fcca0c'.toColor2(),
      appBar: AppBar(
        centerTitle: true,
        toolbarHeight: 50,
        backgroundColor: '#fcca0c'.toColor2(),
        // leading: ElevatedButton.icon(
        //   onPressed: () {
        //     // Add your onPressed code here!
        //     Navigator.pushNamed(context, '/menu');
        //   },
        //   icon:  Icon(Icons.arrow_left_sharp),
        //   label:  Text(''),
        //   style: ElevatedButton.styleFrom(
        //       elevation: 0, primary: Colors.transparent),
        // ),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title + 'La pré-alphabétisation',style: TextStyle(color: Color(0xff000000),fontStyle: FontStyle.italic),),
      ),
      body: SingleChildScrollView(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.


        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize : MainAxisSize.min,

          children: <Widget> [

            Padding(
              padding: EdgeInsets.all(6), //apply padding to all four sides
              child: Text('Une femme libre',style: TextStyle(fontSize: 20),),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,

              children: <Widget>[
                SizedBox(
                  width: 90,
                  height: 50,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        print("tapped");
                      },

                      child: const Icon(Icons.arrow_back),

                    ),
                  ),
                ),
                // Expanded(
                SizedBox(
                  width: 90,
                  height: 90,
                  child: Image(
                    image:AssetImage('assets/prealpha/arcb.png'),
                    width: 90,
                    height: 90,
                  ),

                ),
                // ),
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 150,
                  child: Image(
                    image:AssetImage('assets/icons/teacher.png'),
                    width: 70,
                    height: 70,
                  ),
                ),

                SizedBox(
                  width: 90,
                  height: 50,

                  child:Card(

                    child: new InkWell(
                      onTap: () {
                        print("tapped");
                      },
                      child: const Icon(Icons.arrow_forward),
                    ),
                  ),
                ),

                // ),

              ],
            ),



          ],
        ),

      ),
      // This trailing comma makes auto-formatting nicer for build methods.
      floatingActionButton: Container(
        height: 100.0,
        width: 100.0,
        child: FittedBox(

          child: FloatingActionButton(
              backgroundColor: Colors.amber,
              child: const Icon(Icons.border_color_outlined,color: Colors.black,),
              onPressed: () {
                Navigator.pushNamed(context, '/evaluationSymbol');
          }),
        ),
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
