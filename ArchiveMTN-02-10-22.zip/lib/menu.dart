import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:projets/alphabet.dart';
import 'package:projets/infosymbol.dart';
import 'package:projets/menulecon.dart';
import 'package:projets/ardoise.dart';
import 'package:projets/calculator.dart';
import 'package:projets/adminlogin.dart';

extension ColorExtension on String {
  toColor3() {
    var hexString = this;
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}


void main() {
  runApp(const MyMenu());
}

class MyMenu extends StatelessWidget {
  const MyMenu({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    // Set landscape orientation
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.landscapeLeft,
      DeviceOrientation.landscapeRight,
    ]);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      routes: {
        '/infosymbol': (context) => MySymbolInfo(),
        '/menulecon': (context) => MyMenuL(),
        '/alphabet': (context) => MyAlphabet(),
        '/ardoise': (context) => MyArdoise(),
        '/calculator': (context) => MyCalculator(),


      },
      theme: ThemeData(

        //primarySwatch: '#fcca0c'.toColor2(),
      ),
      home: const MyHomePage(title: ''),
    );
  }
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key, required this.title}) : super(key: key);


  final String title;

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  int _counter = 0;



  @override
  Widget build(BuildContext context) {

    return Scaffold(
      //backgroundColor: '#fcca0c'.toColor2(),
      appBar: AppBar(
        centerTitle: true,
        toolbarHeight: 80,
        backgroundColor: '#fcca0c'.toColor3(),
        // Here we take the value from the MyHomePage object that was created by
        // the App.build method, and use it to set our appbar title.
        title: Text(widget.title + 'Y\'ello Alphabétisation MARIAM \n Qu\'est ce qu\'on fait aujourdhui ?',style: TextStyle(color: Color(0xff000000),fontStyle: FontStyle.italic),),
      ),
      body: SingleChildScrollView(
        // Center is a layout widget. It takes a single child and positions it
        // in the middle of the parent.


        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          mainAxisSize : MainAxisSize.min,

          children: <Widget> [

            Padding(
              padding: EdgeInsets.all(4), //apply padding to all four sides
              child: Text('',style: TextStyle(fontSize: 25),),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 150,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, '/infosymbol');
                        //print("tapped");
                      },
                      child: Image(
                        image:AssetImage('assets/icons/preicon.png'),
                        width: 10,
                        height: 10,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 150,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, '/alphabet');
                        //print("tapped");
                      },
                      child: Center(child: Text('a B c',
                        style: TextStyle(fontSize: 55,
                          fontFamily: 'Poppins',), ),
                      ),
                    ),
                  ),
                ),
                // ),
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 150,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, '/menulecon');
                        //print("tapped");
                      },
                      child: Image(
                        image:AssetImage('assets/icons/book.png'),
                        width: 70,
                        height: 70,
                      ),

                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 150,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        print("tapped");
                      },
                      child: Image(
                        image:AssetImage('assets/icons/pen.png'),
                        width: 70,
                        height: 70,
                      ),
                    ),
                  ),
                ),
                // ),
              ],
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 50,
                  child: Text('Symboles',style: TextStyle(fontSize: 25),textAlign: TextAlign.center,),
                ),
                SizedBox(
                  width: 150,
                  height: 50,
                  child: Text('Alphabets',style: TextStyle(fontSize: 25),textAlign: TextAlign.center,),

                ),
                // ),
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 50,
                  child: Text('Leçons',style: TextStyle(fontSize: 25),textAlign: TextAlign.center,),

                ),
                SizedBox(
                  width: 150,
                  height: 50,
                  child: Text('Evaluations',style: TextStyle(fontSize: 25),textAlign: TextAlign.center,),

                ),
                // ),
              ],
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children:  <Widget>[
                SizedBox(
                  width: 225,
                  height: 150,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        Navigator.pushNamed(context, '/ardoise');
                        //print("tapped");
                      },
                      child: Image(
                        image:AssetImage('assets/icons/board.png'),
                        width: 70,
                        height: 70,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 225,
                  height: 150,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        //print("tapped");
                        Navigator.pushNamed(context, '/calculator');
                      },
                      child: Image(
                        image:AssetImage('assets/icons/calculator.png'),
                        width: 10,
                        height: 10,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150,
                  height: 150,
                  child:Card(
                    child: new InkWell(
                      onTap: () {
                        SystemNavigator.pop();
                      },
                      child: Image.asset(
                        'assets/icons/close.png',
                        scale: 0.5,
                      ),
                    ),
                  ),
                ),
                //),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: <Widget>[
                // Expanded(
                SizedBox(
                  width: 225,
                  height: 50,
                  child: Text('Ardoise',style: TextStyle(fontSize: 25),textAlign: TextAlign.center,),
                ),
                SizedBox(
                  width: 225,
                  height: 50,
                  child: Text('Calculatrice',style: TextStyle(fontSize: 25),textAlign: TextAlign.center,),

                ),
                // ),
                // Expanded(
                SizedBox(
                  width: 150,
                  height: 50,
                  child: Text('Fermer',style: TextStyle(fontSize: 25),textAlign: TextAlign.center,),

                ),

                // ),
              ],
            ),

          ],
        ),
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }
}
